<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$classes = ($active ?? false)
            ? 'flex items-center px-4 py-3 mb-1 rounded-xl bg-gradient-to-r from-chuss-amber/20 to-chuss-amber/5 text-chuss-dark font-bold border-l-4 border-chuss-amber shadow-sm transition-all duration-300 transform scale-[1.02]'
            : 'flex items-center px-4 py-3 mb-1 rounded-xl text-chuss-gray font-medium hover:bg-white/60 hover:text-chuss-dark border-l-4 border-transparent hover:border-chuss-amber/50 transition-all duration-300 hover:translate-x-1 hover:shadow-sm backdrop-blur-sm';
?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/components/sidebar-link.blade.php ENDPATH**/ ?>