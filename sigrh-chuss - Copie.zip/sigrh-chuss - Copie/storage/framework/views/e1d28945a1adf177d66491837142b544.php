<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Comptes SUS')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('status')): ?>
                <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('identifiants')): ?>
                <?php $identifiants = session('identifiants'); ?>
                <div class="bg-amber-50 border border-amber-300 text-amber-900 px-4 py-4 rounded-md space-y-2">
                    <p class="font-semibold">
                        <?php echo e(__('Identifiants générés pour')); ?> <?php echo e($identifiants['nom']); ?>

                        &mdash; <?php echo e(__('à transmettre maintenant, ils ne seront plus affichés ensuite.')); ?>

                    </p>
                    <dl class="grid grid-cols-2 gap-2 text-sm max-w-md">
                        <dt class="text-amber-700"><?php echo e(__('Identifiant')); ?></dt>
                        <dd class="font-mono font-semibold"><?php echo e($identifiants['username']); ?></dd>
                        <dt class="text-amber-700"><?php echo e(__('Mot de passe')); ?></dt>
                        <dd class="font-mono font-semibold"><?php echo e($identifiants['password']); ?></dd>
                    </dl>
                    <?php if($identifiants['email_envoye'] ?? false): ?>
                        <p class="text-sm text-green-700">
                            ✓ <?php echo e(__('Envoyé par email à')); ?> <?php echo e($identifiants['email']); ?>.
                        </p>
                    <?php else: ?>
                        <p class="text-sm text-red-700">
                            ⚠ <?php echo e(__("L'envoi par email a échoué (vérifie la configuration SMTP) — transmets ces identifiants manuellement.")); ?>

                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="flex justify-end">
                <a href="<?php echo e(route('admin.sus.create')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                    <?php echo e(__('Créer un compte SUS')); ?>

                </a>
            </div>

            <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-float rounded-2xl border border-white/60">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead class="bg-gradient-to-r from-chuss-green/5 to-chuss-amber/5 border-b border-gray-100">
                            <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Nom')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Matricule')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Service')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Identifiant')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Email de récupération')); ?></th>
                                <th class="px-6 py-3"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100/50">
                            <?php $__empty_1 = true; $__currentLoopData = $comptes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800"><?php echo e($compte->name); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?php echo e($compte->matricule ?? '—'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?php echo e($compte->service?->nom ?? '—'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-500"><?php echo e($compte->username ?? '—'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?php echo e($compte->email); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                                        <form method="POST" action="<?php echo e(route('admin.sus.reinitialiser-mot-de-passe', $compte)); ?>"
                                              onsubmit="return confirm('<?php echo e(__('Générer un nouveau mot de passe pour ce compte ?')); ?>');">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="text-indigo-600 hover:text-indigo-900">
                                                <?php echo e(__('Réinitialiser le mot de passe')); ?>

                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php echo e(__('Aucun compte SUS créé.')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/admin/sus/index.blade.php ENDPATH**/ ?>