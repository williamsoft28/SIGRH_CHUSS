<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Bon de repas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('status')): ?>
                <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm sm:rounded-lg p-6 space-y-6">
                <dl class="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Bénéficiaire')); ?></dt>
                        <dd class="font-medium text-gray-900"><?php echo e($bon->declarationJour->beneficiaire->nom); ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Service')); ?></dt>
                        <dd class="font-medium text-gray-900"><?php echo e($bon->declarationJour->beneficiaire->service->nom); ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Période')); ?></dt>
                        <dd class="font-medium text-gray-900">
                            <?php echo e($bon->date_debut->format('d/m/Y')); ?>

                            <?php if(! $bon->date_debut->equalTo($bon->date_fin)): ?>
                                &rarr; <?php echo e($bon->date_fin->format('d/m/Y')); ?>

                            <?php endif; ?>
                            (<?php echo e($bon->type_periode); ?>)
                        </dd>
                    </div>
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Canal d’envoi')); ?></dt>
                        <dd class="font-medium text-gray-900 capitalize"><?php echo e($bon->canal_envoi); ?></dd>
                    </div>
                    <div class="col-span-2">
                        <dt class="text-gray-500"><?php echo e(__('Code unique')); ?></dt>
                        <dd class="font-mono text-xs text-gray-900 break-all"><?php echo e($bon->code_unique); ?></dd>
                    </div>
                </dl>

                <div class="flex flex-col items-center gap-4 border-t pt-6">
                    <div class="p-4 bg-white border rounded-md">
                        <?php echo $qr; ?>

                    </div>
                    <a href="<?php echo e(route($routeTelecharger, $bon)); ?>"
                       class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                        <?php echo e(__('Télécharger le QR code')); ?>

                    </a>

                    <div class="flex flex-wrap justify-center gap-3 w-full border-t pt-4">
                        <form method="POST" action="<?php echo e(route($routeEnvoyerEmail, $bon)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                <?php if(empty($bon->declarationJour->beneficiaire->email)): echo 'disabled'; endif; ?>
                                class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed">
                                <?php echo e(__('Envoyer par email')); ?>

                            </button>
                        </form>
                        <?php if (! (empty($bon->declarationJour->beneficiaire->email))): ?>
                            <p class="text-xs text-gray-400 self-center"><?php echo e($bon->declarationJour->beneficiaire->email); ?></p>
                        <?php else: ?>
                            <p class="text-xs text-red-400 self-center"><?php echo e(__('Aucun email renseigné')); ?></p>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route($routeEnvoyerWhatsapp, $bon)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                <?php if(! $aNumeroWhatsapp): echo 'disabled'; endif; ?>
                                class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-500 disabled:opacity-40 disabled:cursor-not-allowed">
                                <?php echo e(__('Envoyer sur WhatsApp')); ?>

                            </button>
                        </form>
                        <?php if (! ($aNumeroWhatsapp)): ?>
                            <p class="text-xs text-red-400 self-center"><?php echo e(__('Aucun numéro WhatsApp renseigné')); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <a href="<?php echo e($retourUrl); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                &larr; <?php echo e(__($retourLabel)); ?>

            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/bons/show.blade.php ENDPATH**/ ?>