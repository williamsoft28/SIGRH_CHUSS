<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Menus hebdomadaires')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('status')): ?>
                <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <div class="flex justify-end">
                <a href="<?php echo e(route('hotellerie.menus.create')); ?>"
                   class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                    <?php echo e(__('Composer un menu')); ?>

                </a>
            </div>

            <?php if($nouveaux->count() > 0): ?>
            <div class="mb-8">
                <h3 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('Nouveaux retours (À valider)')); ?></h3>
                <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-float rounded-2xl border border-red-300">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-red-50 border-b border-red-100">
                                <tr>
                                    <th class="px-6 py-4 text-xs font-bold text-red-800 uppercase tracking-wider"><?php echo e(__('Semaine')); ?></th>
                                    <th class="px-6 py-4 text-xs font-bold text-red-800 uppercase tracking-wider"><?php echo e(__('Période')); ?></th>
                                    <th class="px-6 py-4 text-xs font-bold text-red-800 uppercase tracking-wider"><?php echo e(__('Statut')); ?></th>
                                    <th class="px-6 py-3"></th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100/50">
                                <?php $__currentLoopData = $nouveaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-red-50/50 transition-colors duration-200">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800">S<?php echo e($menu->numero_semaine); ?> / <?php echo e($menu->annee); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            <?php echo e($menu->date_debut->format('d/m/Y')); ?> &rarr; <?php echo e($menu->date_fin->format('d/m/Y')); ?>

                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                                            <?php if (isset($component)) { $__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu-statut-badge','data' => ['statut' => $menu->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-statut-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['statut' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b)): ?>
<?php $attributes = $__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b; ?>
<?php unset($__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b)): ?>
<?php $component = $__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b; ?>
<?php unset($__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b); ?>
<?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                                            <a href="<?php echo e(route('hotellerie.menus.show', $menu)); ?>" class="text-indigo-600 hover:text-indigo-900 font-bold">
                                                <?php echo e(__('Ouvrir et Valider')); ?>

                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <h3 class="text-lg font-medium text-gray-900 mb-4"><?php echo e(__('Tous les menus')); ?></h3>
            <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-float rounded-2xl border border-white/60">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead class="bg-gradient-to-r from-chuss-green/5 to-chuss-amber/5 border-b border-gray-100">
                            <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Semaine')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Période')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Statut')); ?></th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider"><?php echo e(__('Modifications')); ?></th>
                                <th class="px-6 py-3"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100/50">
                            <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800">S<?php echo e($menu->numero_semaine); ?> / <?php echo e($menu->annee); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php echo e($menu->date_debut->format('d/m/Y')); ?> &rarr; <?php echo e($menu->date_fin->format('d/m/Y')); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if (isset($component)) { $__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu-statut-badge','data' => ['statut' => $menu->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-statut-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['statut' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b)): ?>
<?php $attributes = $__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b; ?>
<?php unset($__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b)): ?>
<?php $component = $__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b; ?>
<?php unset($__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b); ?>
<?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600"><?php echo e($menu->nb_modifications); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                                        <a href="<?php echo e(route('hotellerie.menus.show', $menu)); ?>" class="text-indigo-600 hover:text-indigo-900">
                                            <?php echo e(__('Voir')); ?>

                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <td colspan="5" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php echo e(__('Aucun menu créé pour le moment.')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                <?php echo e($menus->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/hotellerie/menus/index.blade.php ENDPATH**/ ?>