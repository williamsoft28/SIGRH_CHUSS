﻿<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Menu')); ?> — S<?php echo e($menu->numero_semaine); ?> / <?php echo e($menu->annee); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if(session('status')): ?>
                <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-md">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($erreur); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm sm:rounded-lg p-6 flex justify-between items-start"><div class="flex-1">
                <dl class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Période')); ?></dt>
                        <dd class="font-medium text-gray-900"><?php echo e($menu->date_debut->format('d/m/Y')); ?> &rarr; <?php echo e($menu->date_fin->format('d/m/Y')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Statut')); ?></dt>
                        <dd><?php if (isset($component)) { $__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu-statut-badge','data' => ['statut' => $menu->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu-statut-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['statut' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b)): ?>
<?php $attributes = $__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b; ?>
<?php unset($__attributesOriginalbc6e68d8c9a6de74057f59a78d0d107b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b)): ?>
<?php $component = $__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b; ?>
<?php unset($__componentOriginalbc6e68d8c9a6de74057f59a78d0d107b); ?>
<?php endif; ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Soumis le')); ?></dt>
                        <dd class="font-medium text-gray-900"><?php echo e($menu->date_soumission?->format('d/m/Y H:i') ?? '—'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-gray-500"><?php echo e(__('Validé le')); ?></dt>
                        <dd class="font-medium text-gray-900"><?php echo e($menu->date_validation?->format('d/m/Y H:i') ?? '—'); ?></dd>
                    </div>
                </dl></div><div class="ml-4"><a href="<?php echo e(route('menus.telecharger', $menu)); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700">T�l�charger PDF</a></div></div>
                <?php if($menu->statut === 'applique'): ?>
                    <p class="text-xs text-gray-400 mt-4">
                        <?php echo e(__('Modifications déjà utilisées cette semaine :')); ?> <?php echo e($menu->nb_modifications); ?> / 1
                    </p>
                <?php endif; ?>
            </div>

            <?php if($menu->observations->isNotEmpty()): ?>
                <div class="bg-white shadow-sm sm:rounded-lg p-6 flex justify-between items-start"><div class="flex-1">
                    <h3 class="font-medium text-gray-900 mb-4"><?php echo e(__('Observations du prestataire')); ?></h3>
                    <ul class="space-y-3">
                        <?php $__currentLoopData = $menu->observations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="border-b pb-3 flex items-start justify-between gap-4">
                                <div>
                                    <p class="text-sm text-gray-700"><?php echo e($observation->contenu); ?></p>
                                    <p class="text-xs text-gray-400 mt-1"><?php echo e($observation->date_emission->format('d/m/Y H:i')); ?></p>
                                </div>
                                <div class="flex items-center gap-2 shrink-0">
                                    <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo e($observation->statut === 'traitee' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'); ?>">
                                        <?php echo e($observation->statut === 'traitee' ? __('Traitée') : __('Ouverte')); ?>

                                    </span>
                                    <?php if($observation->statut === 'ouverte'): ?>
                                        <form method="POST" action="<?php echo e(route('hotellerie.observations.traiter', $observation)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="text-xs text-indigo-600 hover:text-indigo-900">
                                                <?php echo e(__('Marquer traitée')); ?>

                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($menu->statut === 'en_observation'): ?>
                <form method="POST" action="<?php echo e(route('hotellerie.menus.valider', $menu)); ?>"
                      onsubmit="return confirm('<?php echo e(__('Valider et appliquer ce menu ?')); ?>');">
                    <?php echo csrf_field(); ?>
                    <div class="flex justify-end">
                        <button type="submit"
                            class="inline-flex items-center px-4 py-2 bg-green-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-green-500">
                            <?php echo e(__('Valider et appliquer')); ?>

                        </button>
                    </div>
                </form>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('hotellerie.menus.update', $menu)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <?php echo $__env->make('hotellerie.menus._grille', ['lecture' => ! $peutModifier], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php if($peutModifier): ?>
                    <div class="flex items-center justify-end mt-6 gap-4">
                        <a href="<?php echo e(route('hotellerie.menus.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                            <?php echo e(__('Retour')); ?>

                        </a>
                        <button type="submit"
                            class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                            <?php echo e($menu->statut === 'applique' ? __('Enregistrer la modification') : __('Enregistrer')); ?>

                        </button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/hotellerie/menus/show.blade.php ENDPATH**/ ?>