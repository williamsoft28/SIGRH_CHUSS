<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-center space-y-4">
        <h1 class="text-lg font-semibold text-gray-900"><?php echo e(__('Votre bon de repas')); ?></h1>

        <p class="text-sm bg-indigo-50 text-indigo-900 rounded-md px-3 py-2">
            <?php echo e(__('Montrez cet écran (ou le QR ci-dessous) au réfectoire pour chaque repas concerné.')); ?>

        </p>

        <div class="flex justify-center py-2">
            <div class="p-4 bg-white border-2 border-gray-200 rounded-md">
                <?php echo $qr; ?>

            </div>
        </div>

        <a href="<?php echo e(route('bons.public.telecharger', $bon->code_unique)); ?>"
           class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
            <?php echo e(__('Enregistrer le QR code')); ?>

        </a>

        <dl class="text-sm text-left space-y-1 border-t pt-4 mt-4">
            <div class="flex justify-between">
                <dt class="text-gray-500"><?php echo e(__('Bénéficiaire')); ?></dt>
                <dd class="font-medium text-gray-900"><?php echo e($bon->declarationJour->beneficiaire->nom); ?></dd>
            </div>
            <div class="flex justify-between">
                <dt class="text-gray-500"><?php echo e(__('Service')); ?></dt>
                <dd class="font-medium text-gray-900"><?php echo e($bon->declarationJour->beneficiaire->service?->nom ?? '—'); ?></dd>
            </div>
            <div class="flex justify-between">
                <dt class="text-gray-500"><?php echo e(__('Période')); ?></dt>
                <dd class="font-medium text-gray-900">
                    <?php echo e($bon->date_debut->format('d/m/Y')); ?>

                    <?php if(! $bon->date_debut->equalTo($bon->date_fin)): ?>
                        &rarr; <?php echo e($bon->date_fin->format('d/m/Y')); ?>

                    <?php endif; ?>
                </dd>
            </div>
            <div class="flex justify-between">
                <dt class="text-gray-500"><?php echo e(__('Repas')); ?></dt>
                <dd class="font-medium text-gray-900">
                    <?php echo e(collect($bon->declarationJour->repas ?? [])->map(fn ($r) => str_replace('_', ' ', $r))->implode(', ')); ?>

                </dd>
            </div>
        </dl>

        <p class="text-xs font-mono text-gray-400 break-all">
            <?php echo e($bon->code_unique); ?>

        </p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/bons/public.blade.php ENDPATH**/ ?>