<?php
    $lecture ??= false;
    $libellesRepas = [
        'petit_dejeuner' => 'Petit-déjeuner',
        'dejeuner' => 'Déjeuner',
        'diner' => 'Dîner',
    ];
?>

<div class="space-y-6">
    <?php $__currentLoopData = $jours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $dateStr = $jour->toDateString(); ?>
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-4">
            <h4 class="font-medium text-gray-900 mb-3">
                <span class="capitalize"><?php echo e($jour->locale('fr')->translatedFormat('l')); ?></span>
                <span class="text-gray-400 font-normal"><?php echo e($jour->format('d/m/Y')); ?></span>
            </h4>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-gradient-to-r from-chuss-green/5 to-chuss-amber/5 border-b border-gray-100">
                        <tr class="hover:bg-white/60 transition-colors duration-200 group">
                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Repas')); ?></th>
                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Plat')); ?></th>
                            
                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Viande')); ?></th>
                            <th class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Dessert')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100/50">
                        <?php $__currentLoopData = $libellesRepas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeRepas => $libelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $selection = $repasExistant[$dateStr][$typeRepas] ?? [];
                                $platsDisponibles = $typeRepas === 'petit_dejeuner' ? $platsPetitDej : $platsBase;
                            ?>
                            <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                <td class="px-3 py-2 text-sm font-medium text-gray-900 whitespace-nowrap"><?php echo e($libelle); ?></td>

                                <?php if($lecture): ?>
                                    <td class="px-3 py-2 text-sm text-gray-700"><?php echo e($platsDisponibles->firstWhere('id', $selection['plat_id'] ?? null)->nom ?? '—'); ?></td>
                                    <?php if($typeRepas === 'petit_dejeuner'): ?>
                                        <td class="px-3 py-2 text-sm text-gray-400 italic text-center bg-gray-50">—</td>
                                        <td class="px-3 py-2 text-sm text-gray-400 italic text-center bg-gray-50">—</td>
                                    <?php else: ?>
                                        <td class="px-3 py-2 text-sm text-gray-700"><?php echo e($viandes->firstWhere('id', $selection['viande_id'] ?? null)->nom ?? '—'); ?></td>
                                        <td class="px-3 py-2 text-sm text-gray-700"><?php echo e($desserts->firstWhere('id', $selection['dessert_id'] ?? null)->nom ?? '—'); ?></td>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <td class="px-3 py-2">
                                        <select name="repas[<?php echo e($dateStr); ?>][<?php echo e($typeRepas); ?>][plat_id]"
                                            class="block w-full text-sm border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                            <option value="">Sélectionnez un plat...</option>
                                            <?php $__currentLoopData = $platsDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($plat->id); ?>" <?php if(old("repas.{$dateStr}.{$typeRepas}.plat_id", $selection['plat_id'] ?? null) == $plat->id): echo 'selected'; endif; ?>>
                                                    <?php echo e($plat->nom); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <?php if($typeRepas === 'petit_dejeuner'): ?>
                                        <td class="px-3 py-2 text-sm text-gray-400 italic text-center bg-gray-50">N/A</td>
                                        <td class="px-3 py-2 text-sm text-gray-400 italic text-center bg-gray-50">N/A</td>
                                    <?php else: ?>
                                        <td class="px-3 py-2">
                                            <select name="repas[<?php echo e($dateStr); ?>][<?php echo e($typeRepas); ?>][viande_id]"
                                                class="block w-full text-sm border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                                <option value="">—</option>
                                                <?php $__currentLoopData = $viandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($viande->id); ?>" <?php if(old("repas.{$dateStr}.{$typeRepas}.viande_id", $selection['viande_id'] ?? null) == $viande->id): echo 'selected'; endif; ?>>
                                                        <?php echo e($viande->nom); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td class="px-3 py-2">
                                            <select name="repas[<?php echo e($dateStr); ?>][<?php echo e($typeRepas); ?>][dessert_id]"
                                                class="block w-full text-sm border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                                <option value="">—</option>
                                                <?php $__currentLoopData = $desserts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dessert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($dessert->id); ?>" <?php if(old("repas.{$dateStr}.{$typeRepas}.dessert_id", $selection['dessert_id'] ?? null) == $dessert->id): echo 'selected'; endif; ?>>
                                                        <?php echo e($dessert->nom); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/hotellerie/menus/_grille.blade.php ENDPATH**/ ?>