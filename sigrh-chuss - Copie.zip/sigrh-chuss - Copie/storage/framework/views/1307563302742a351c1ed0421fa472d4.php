<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Déclarer les bénéficiaires du jour')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-md">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($erreur); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                <form method="GET" action="<?php echo e(route('declarations.create')); ?>" class="flex items-end gap-4">
                    <div>
                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'date','value' => __('Date de repas')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'date','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Date de repas'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'date','name' => 'date','type' => 'date','class' => 'mt-1','value' => ''.e($date->toDateString()).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'date','name' => 'date','type' => 'date','class' => 'mt-1','value' => ''.e($date->toDateString()).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?><?php echo e(__('Charger')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                </form>
            </div>

            <?php if (! ($ouverte)): ?>
                <div class="bg-amber-100 border border-amber-300 text-amber-900 px-4 py-3 rounded-md flex items-center justify-between">
                    <span>
                        <?php echo e(__("La saisie est verrouillée pour le :date (après 09h00).", ['date' => $date->format('d/m/Y')])); ?>

                    </span>
                    <a href="<?php echo e(route('derogations.index')); ?>" class="font-semibold underline">
                        <?php echo e(__('Demander une dérogation')); ?>

                    </a>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('declarations.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="date" value="<?php echo e($date->toDateString()); ?>">

                <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-float rounded-2xl border border-white/60">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse no-grid">
                            <thead class="bg-gradient-to-r from-chuss-green/5 to-chuss-amber/5 border-b border-gray-100">
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Mange ce jour')); ?></th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Bénéficiaire')); ?></th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Repas concernés')); ?></th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo e(__('Période (réguliers)')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100/50">
                                <?php $__empty_1 = true; $__currentLoopData = $beneficiaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $dejaDeclare = in_array($beneficiaire->id, $dejaDeclares);
                                        $estGarde = str_contains(strtolower($beneficiaire->categorie), 'garde');
                                    ?>
                                    <tr class="hover:bg-white/60 transition-colors duration-200 group" x-data="{ open: false }" class="align-top">
                                        <td class="px-4 py-4">
                                            <?php if($dejaDeclare): ?>
                                                <span class="text-xs text-gray-400"><?php echo e(__('Déjà déclaré(e)')); ?></span>
                                            <?php else: ?>
                                                <input type="checkbox" x-model="open"
                                                    name="declarer[<?php echo e($beneficiaire->id); ?>]" value="1"
                                                    class="rounded border-gray-300 text-indigo-600 shadow-sm">
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-4 text-sm text-gray-900">
                                            <div class="font-medium"><?php echo e($beneficiaire->nom); ?></div>
                                            <div class="text-xs text-gray-500">
                                                <?php echo e($beneficiaire->categorie); ?> &middot;
                                                <?php echo e($beneficiaire->type === 'regulier' ? 'Régulier' : 'Variable'); ?>

                                            </div>
                                        </td>
                                        <td class="px-4 py-4" x-show="open" style="display: none;">
                                            <div class="space-y-1 text-sm text-gray-700">
                                                <label class="flex items-center gap-2">
                                                    <input type="checkbox" name="repas[<?php echo e($beneficiaire->id); ?>][]" value="petit_dejeuner"
                                                        <?php if($estGarde): echo 'checked'; endif; ?> class="rounded border-gray-300 text-indigo-600 shadow-sm">
                                                    <?php echo e(__('Petit-déjeuner')); ?>

                                                </label>
                                                <label class="flex items-center gap-2">
                                                    <input type="checkbox" name="repas[<?php echo e($beneficiaire->id); ?>][]" value="dejeuner"
                                                        <?php if(! $estGarde): echo 'checked'; endif; ?> class="rounded border-gray-300 text-indigo-600 shadow-sm">
                                                    <?php echo e(__('Déjeuner')); ?>

                                                </label>
                                                <label class="flex items-center gap-2">
                                                    <input type="checkbox" name="repas[<?php echo e($beneficiaire->id); ?>][]" value="diner"
                                                        <?php if($estGarde): echo 'checked'; endif; ?> class="rounded border-gray-300 text-indigo-600 shadow-sm">
                                                    <?php echo e(__('Dîner')); ?>

                                                </label>
                                                <?php if($estGarde): ?>
                                                    <p class="text-xs text-gray-400"><?php echo e(__('Agent de garde : petit-déjeuner + dîner suggérés.')); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="px-4 py-4" x-show="open" style="display: none;">
                                            <?php if($beneficiaire->type === 'regulier'): ?>
                                                <div class="space-y-2">
                                                    <select name="type_periode[<?php echo e($beneficiaire->id); ?>]"
                                                        class="block w-full text-sm border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                                        <option value="hebdomadaire"><?php echo e(__('Hebdomadaire')); ?></option>
                                                        <option value="mensuel"><?php echo e(__('Mensuel')); ?></option>
                                                    </select>
                                                    <div class="flex gap-2">
                                                        <input type="date" name="date_debut[<?php echo e($beneficiaire->id); ?>]"
                                                            value="<?php echo e($date->toDateString()); ?>"
                                                            class="block w-full text-sm border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                                        <input type="date" name="date_fin[<?php echo e($beneficiaire->id); ?>]"
                                                            class="block w-full text-sm border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                                    </div>
                                                    <p class="text-xs text-gray-400"><?php echo e(__('Laisser la date de fin vide pour une période par défaut (7 ou 30 jours).')); ?></p>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-xs text-gray-400"><?php echo e(__('Déclaration quotidienne, pour cette date uniquement.')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                        <td colspan="4" class="px-4 py-4 text-center text-sm text-gray-500">
                                            <?php echo e(__("Aucun bénéficiaire enregistré pour votre service.")); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="flex items-center justify-end mt-6 gap-4">
                    <a href="<?php echo e(route('declarations.index')); ?>" class="text-sm text-gray-600 hover:text-gray-900">
                        <?php echo e(__('Annuler')); ?>

                    </a>
                    <button type="submit" <?php if(! $ouverte): echo 'disabled'; endif; ?>
                        class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed">
                        <?php echo e(__('Enregistrer la déclaration')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/declarations/creer.blade.php ENDPATH**/ ?>