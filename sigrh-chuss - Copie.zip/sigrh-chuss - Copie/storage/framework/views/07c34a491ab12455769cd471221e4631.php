<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['statut']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['statut']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $libelles = [
        'demandee' => 'Demandée',
        'autorisee' => 'Autorisée',
        'refusee' => 'Refusée',
    ];

    $classes = [
        'demandee' => 'bg-amber-100 text-amber-800',
        'autorisee' => 'bg-green-100 text-green-800',
        'refusee' => 'bg-red-100 text-red-800',
    ];
?>

<span <?php echo e($attributes->merge(['class' => 'inline-flex px-2 py-1 text-xs font-semibold rounded-full '.($classes[$statut] ?? 'bg-gray-100 text-gray-800')])); ?>>
    <?php echo e($libelles[$statut] ?? $statut); ?>

</span>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/components/derogation-statut-badge.blade.php ENDPATH**/ ?>