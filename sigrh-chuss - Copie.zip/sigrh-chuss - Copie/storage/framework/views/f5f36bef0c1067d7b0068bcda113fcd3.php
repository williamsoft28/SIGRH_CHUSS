<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Menu Semaine <?php echo e($menu->numero_semaine); ?> / <?php echo e($menu->annee); ?></title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        .text-center { text-align: center; }
        .logo { width: 100px; height: auto; margin-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f3f4f6; }
        .bg-gray { background-color: #f9fafb; font-weight: bold; }
    </style>
</head>
<body>
    <div class="text-center">
        <img src="<?php echo e(public_path('images/logo.png')); ?>" class="logo" alt="Logo CHUSS">
        <h2>Menu de la Semaine <?php echo e($menu->numero_semaine); ?> / <?php echo e($menu->annee); ?></h2>
        <p>Du <?php echo e($menu->date_debut->format('d/m/Y')); ?> au <?php echo e($menu->date_fin->format('d/m/Y')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Jour</th>
                <th>Repas</th>
                <th>Plat</th>
                <th>Sauce</th>
                <th>Viande</th>
                <th>Dessert</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $menu->menuJours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuJour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = ['petit_dejeuner' => 'Petit-déjeuner', 'dejeuner' => 'Déjeuner', 'diner' => 'Dîner']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $libelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $repas = $menuJour->repas->firstWhere('type_repas', $type);
                    ?>
                    <tr>
                        <?php if($loop->first): ?>
                            <td rowspan="3" class="bg-gray" style="vertical-align: middle;">
                                <?php echo e($menuJour->jour_semaine); ?><br>
                                <?php echo e($menuJour->date_jour->format('d/m/Y')); ?>

                            </td>
                        <?php endif; ?>
                        <td><?php echo e($libelle); ?></td>
                        <td><?php echo e($repas->plat->nom ?? '-'); ?></td>
                        <td><?php echo e($repas->sauce->nom ?? '-'); ?></td>
                        <td><?php echo e($repas->viande->nom ?? '-'); ?></td>
                        <td><?php echo e($repas->dessert->nom ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\wamp64\www\sigrh_chuss\SIGRH_CHUSS\sigrh-chuss\resources\views/menus/pdf.blade.php ENDPATH**/ ?>