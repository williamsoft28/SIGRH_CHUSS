<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Menus hebdomadaires') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if (session('status'))
                <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded-md">
                    {{ session('status') }}
                </div>
            @endif

            <div class="flex justify-end">
                <a href="{{ route('hotellerie.menus.create') }}"
                   class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                    {{ __('Composer un menu') }}
                </a>
            </div>

            @if($nouveaux->count() > 0)
            <div class="mb-8">
                <h3 class="text-lg font-medium text-gray-900 mb-4">{{ __('Nouveaux retours (À valider)') }}</h3>
                <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-float rounded-2xl border border-red-300">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-red-50 border-b border-red-100">
                                <tr>
                                    <th class="px-6 py-4 text-xs font-bold text-red-800 uppercase tracking-wider">{{ __('Semaine') }}</th>
                                    <th class="px-6 py-4 text-xs font-bold text-red-800 uppercase tracking-wider">{{ __('Période') }}</th>
                                    <th class="px-6 py-4 text-xs font-bold text-red-800 uppercase tracking-wider">{{ __('Statut') }}</th>
                                    <th class="px-6 py-3"></th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100/50">
                                @foreach ($nouveaux as $menu)
                                    <tr class="hover:bg-red-50/50 transition-colors duration-200">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800">S{{ $menu->numero_semaine }} / {{ $menu->annee }}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            {{ $menu->date_debut->format('d/m/Y') }} &rarr; {{ $menu->date_fin->format('d/m/Y') }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                                            <x-menu-statut-badge :statut="$menu->statut" />
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                                            <a href="{{ route('hotellerie.menus.show', $menu) }}" class="text-indigo-600 hover:text-indigo-900 font-bold">
                                                {{ __('Ouvrir et Valider') }}
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif

            <h3 class="text-lg font-medium text-gray-900 mb-4">{{ __('Tous les menus') }}</h3>
            <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-float rounded-2xl border border-white/60">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead class="bg-gradient-to-r from-chuss-green/5 to-chuss-amber/5 border-b border-gray-100">
                            <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider">{{ __('Semaine') }}</th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider">{{ __('Période') }}</th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider">{{ __('Statut') }}</th>
                                <th class="px-6 py-4 text-xs font-bold text-chuss-dark uppercase tracking-wider">{{ __('Modifications') }}</th>
                                <th class="px-6 py-3"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100/50">
                            @forelse ($menus as $menu)
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800">S{{ $menu->numero_semaine }} / {{ $menu->annee }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        {{ $menu->date_debut->format('d/m/Y') }} &rarr; {{ $menu->date_fin->format('d/m/Y') }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <x-menu-statut-badge :statut="$menu->statut" />
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{{ $menu->nb_modifications }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                                        <a href="{{ route('hotellerie.menus.show', $menu) }}" class="text-indigo-600 hover:text-indigo-900">
                                            {{ __('Voir') }}
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr class="hover:bg-white/60 transition-colors duration-200 group">
                                    <td colspan="5" class="px-6 py-4 text-center text-sm text-gray-500">
                                        {{ __('Aucun menu créé pour le moment.') }}
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                {{ $menus->links() }}
            </div>
        </div>
    </div>
</x-app-layout>
